
import os
import csv
from django.http import HttpResponse
from django.contrib import admin
from django.urls import reverse
from django.utils.http import urlencode
from django.utils.html import format_html

# Register your models here.

from .models import Bloodbank,Hospital,Donor,Recipient,Feedback,Plasma
from django.contrib import admin



class ExportCsvMixin:
    def export_as_csv(self, request, queryset):

        meta = self.model._meta
        field_names = [field.name for field in meta.fields]

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename={}.csv'.format(meta)
        writer = csv.writer(response)

        writer.writerow(field_names)
        for obj in queryset:
            row = writer.writerow([getattr(obj, field) for field in field_names])

        return response

    export_as_csv.short_description = "Export Selected"

@admin.register(Hospital)
class HospitalAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ("Name", "City","District","State","Phone")
    list_filter = ("City","District","State")
    actions = ["export_as_csv"]
    search_fields = ("Name__startswith", )
@admin.register(Bloodbank)
class BloodbankAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ("Name", "City","District","State","Phone","view_plasma_link")
    list_filter = ("City","District","State")
    actions = ["export_as_csv"]
    search_fields = ("Name__startswith", )
    def view_plasma_link(self,obj):
        count = obj.plasma_set.count()
        url = (
            reverse("admin:portal_plasma_changelist")
            + "?"
            + urlencode({"Bloodbank": f"{obj.id}"})
        )
        return format_html('<a href="{}">{} Plasma</a>', url, count)
    view_plasma_link.short_description="Plasma"

"""@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ("Name", "City","District","State","Phone")
    list_filter = ("City","District","State")
    actions = ["export_as_csv"]
    search_fields = ("Name__startswith", )"""
@admin.register(Donor)
class DonorAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ("Name", "City","District","State","Phone")
    list_filter = ("City","District","State")
    actions = ["export_as_csv"]
    search_fields = ("Name__istartswith", )
@admin.register(Recipient)
class RecipientAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ("Name", "City","District","State","Phone")
    list_filter = ("City","District","State")
    actions = ["export_as_csv"]
    search_fields = ("Name__istartswith", )
@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ("Rating", "Name", "Comments")
    list_filter = ("Rating","Name")
    actions = ["export_as_csv"]
    search_fields = ("Comments__icontains", )
@admin.register(Plasma)
class PlasmaAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ("Bloodgroup", "Status","AvailableQty" )
    list_filter = ("Bloodgroup","Status")
    actions = ["export_as_csv"]
    search_fields = ("Donor__Name__icontains", )