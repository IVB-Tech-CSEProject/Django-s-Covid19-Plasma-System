from django.shortcuts import render
from django.db.models import Avg, Max, Min, Sum
# Create your views here.
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from .models import Bloodbank,Hospital,Patient,Donor,Recipient,Feedback,Plasma
from django.contrib.auth import get_user_model

@login_required

#def index(request):
#    return HttpResponse("Hello, world. You're at the plasma portal.")

def index(request):
    num_bloodbanks = Bloodbank.objects.all().count()
    num_hospitals = Hospital.objects.all().count()
    num_donors = Donor.objects.all().count()
    num_patients = Donor.objects.all().count()
    num_recipients = Recipient.objects.all().count()
    num_plasma = Plasma.objects.all().count()
    num_feedback = Feedback.objects.all().count()
    apositive_qty = int(
        Plasma.objects.filter(Bloodgroup='A RhD positive').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0)
    anegative_qty = int(
        Plasma.objects.filter(Bloodgroup='A RhD negative').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0)
    bpositive_qty = int(
        Plasma.objects.filter(Bloodgroup='B RhD positive').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0)
    bnegative_qty = int(
        Plasma.objects.filter(Bloodgroup='B RhD negative').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0)
    opositive_qty = int(
        Plasma.objects.filter(Bloodgroup='O RhD positive').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0)
    onegative_qty = int(
        Plasma.objects.filter(Bloodgroup='O RhD negative').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                              0.0) or 0)
    abpositive_qty = int(
        Plasma.objects.filter(Bloodgroup='AB RhD positive').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                               0.0) or 0)
    abnegative_qty = int(
        Plasma.objects.filter(Bloodgroup='AB RhD negative').aggregate(Sum('AvailableQty')).get('AvailableQty__sum',
                                                                                               0.0) or 0)
    """"apositive_qty = int(Plasma.objects.filter(Bloodgroup='A RhD positive',Recipient_isnull=True).aggregate(Sum('AvailableQty')).get('AvailableQty_sum',0.0) or 0)
    anegative_qty = int(Plasma.objects.filter(Bloodgroup='A RhD negative',Recipient_isnull=True).aggregate(Sum('AvailableQty')).get('AvailableQty_sum',0.0) or 0)
    bpositive_qty = int(Plasma.objects.filter(Bloodgroup='B RhD positive',Recipient_isnull=True).aggregate(Sum('AvailableQty')).get('AvailableQty_sum',0.0) or 0)
    bnegative_qty = int(Plasma.objects.filter(Bloodgroup='B RhD negative',Recipient_isnull=True).aggregate(Sum('AvailableQty')).get('AvailableQty_sum',0.0) or 0)
    opositive_qty = int(Plasma.objects.filter(Bloodgroup='O RhD positive',Recipient_isnull=True).aggregate(Sum('AvailableQty')).get('AvailableQty_sum',0.0) or 0)
    onegative_qty = int(Plasma.objects.filter(Bloodgroup='O RhD negative',Recipient_isnull=True).aggregate(Sum('AvailableQty')).get('AvailableQty_sum',0.0) or 0)
    abpositive_qty = int(Plasma.objects.filter(Bloodgroup='AB RhD positive',Recipient_isnull=True).aggregate(Sum('AvailableQty')).get('AvailableQty_sum',0.0) or 0)
    abnegative_qty = int(Plasma.objects.filter(Bloodgroup='AB RhD negative',Recipient_isnull=True).aggregate(Sum('AvailableQty')).get('AvailableQty_sum',0.0) or 0)"""

    user = get_user_model()
    num_users = user.objects.all().count()
    hospital_perm = request.user.has_perm('portal.view_hosptial')
    donor_perm = request.user.has_perm('portal.view_donor')
    patient_perm = request.user.has_perm('portal.view_patient')
    feedback_perm = request.user.has_perm('portal.view_feedback')
    bloodbank_perm = request.user.has_perm('portal.view_bloodbank')
    plasma_perm = request.user.has_perm('portal.view_plasma')
    recipient_perm = request.user.has_perm('portal.view_recipient')
    group_perm = request.user.has_perm('auth.view_group')
    user_perm = request.user.has_perm('auth.view_user')
    context ={
        'apositive_qty':apositive_qty,
        'anegative_qty':anegative_qty,
        'bpositive_qty':bpositive_qty,
        'bnegative_qty':bnegative_qty,
        'opositive_qty':opositive_qty,
        'onegative_qty':onegative_qty,
        'abpositive_qty':abpositive_qty,
        'abnegative_qty':abnegative_qty,
        'num_bloodbanks':num_bloodbanks,
        'num_hospitals':num_hospitals,
        'num_donors':num_donors,
        'num_patients':num_patients,
        'num_recipients':num_recipients,
        'num_plasma':num_plasma,
        'num_feedback':num_feedback,
        'num_users':num_users,
        'hospital_perm':hospital_perm,
        'donor_perm':donor_perm,
        'patient_perm':patient_perm,
        'feedback_perm':feedback_perm,
        'bloodbank_perm':bloodbank_perm,
        'plasma_perm':plasma_perm,
        'recipient_perm':recipient_perm,
        'group_perm':group_perm,
        'user_perm':user_perm,
    }
    # Render the HTML template index.html with the data in the context variable
    return render(request, 'index.html', context=context)
