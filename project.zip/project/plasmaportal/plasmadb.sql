create database plasma;
create user 'plasmausr'@'%' identified by 'Plasma#123';
grant all on plasma.* to 'plasmausr'@'%' ;
