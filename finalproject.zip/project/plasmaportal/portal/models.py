import csv
from django.http import HttpResponse
from django.db import models
from django.contrib import admin
from datetime import date
from datetime import timedelta
from django.core.exceptions import ValidationError
from django.contrib import messages
from django.db.models import Avg, Max, Min, Sum
# Create your models here.


def limit_donors_30days():
    days30 = date.today() + timedelta(days=-30)
    return {'CovidNegativeDate__lte':days30}

class Hospital(models.Model):
    HospitalID = models.IntegerField
    Name = models.CharField(max_length=100,blank=False)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    ACtive = models.BooleanField

    def __str__(self):
        return f"{self.Name}, {self.City}"

    class Meta:
        ordering = ("City", "Name")




class Bloodbank(models.Model):
    BloodbankID = models.IntegerField
    Name = models.CharField(max_length=100)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    ACtive = models.BooleanField

    def __str__(self):
        return f"{self.Name}, {self.City}"

BLOODGROUP_CHOICES = [
    ('A RhD positive', 'A+'),
    ('A RhD negative', 'A-'),
    ('B RhD positive', 'B+'),
    ('B RhD negative', 'B-'),
    ('O RhD positive', 'O+'),
    ('O RhD negative', 'O-'),
    ('AB RhD positive', 'AB+'),
    ('AB RhD negative', 'AB-'),
]

GENDER_CHOICES =[
    ('Male', 'M'),
    ('Female', 'F'),
]


class Donor(models.Model):
    DonorID = models.IntegerField
    Name = models.CharField(max_length=100)
    Age = models.IntegerField
    Gender = models.CharField(max_length=10,
    choices=GENDER_CHOICES)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    Active = models.BooleanField
    BloodGroup = models.CharField(max_length=30,
    choices=BLOODGROUP_CHOICES)
    CovidPositiveDate = models.DateField()
    CovidNegativeDate = models.DateField()

    def __str__(self):
        return f"{self.Name}, {self.City}"
    def clean(self):
        days30 = date.today() + timedelta(days=-30)
        if self.CovidNegativeDate > days30:
            raise ValidationError("30 days must be completed to donate from negative date")
        if self.CovidPositiveDate > self.CovidNegativeDate:
            raise ValidationError("Covid postive date must be before negative date")
  

class Recipient(models.Model):
    RecipientID = models.IntegerField
    Name = models.CharField(max_length=100)
    Age = models.IntegerField
    Aadhar = models.CharField(max_length=12)
    Gender = models.CharField(max_length=10,
    choices=GENDER_CHOICES)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    ACtive = models.BooleanField
    BloodGroup = models.CharField(max_length=30,
    choices=BLOODGROUP_CHOICES)
    CovidPositiveDate = models.DateField()
    CovidNegativeDate = models.DateField(blank=True)
    PlasmaDelivered=models.BooleanField(null=True)
    PlasmaQuantity=models.PositiveIntegerField(null=True)
    PlasmaDeliveryDate = models.DateField(null=True)

    def __str__(self):
        return f"{self.Name}, {self.City}"
    def clean(self):
        availableqty = int(Plasma.objects.filter(Bloodgroup=self.BloodGroup).aggregate(Sum('AvailableQty')).get('AvailableQty__sum',0.0) or 0)        
        if self.PlasmaQuantity > availableqty:
            raise ValidationError("Requested Quantity is not available....(Available Qty:"+str(availableqty)+")")

class Patient(models.Model):
    PatientID = models.IntegerField
    Name = models.CharField(max_length=100)
    Age = models.IntegerField
    Gender = models.CharField(max_length=10,
    choices=GENDER_CHOICES)
    City = models.CharField(max_length=100)
    District = models.CharField(max_length=100)
    State = models.CharField(max_length=100)
    Pincode = models.CharField(max_length=6)
    Phone = models.CharField(max_length=20)
    Contact = models.CharField(max_length=100)
    ACtive = models.BooleanField
    BloodGroup = models.CharField(max_length=30,
    choices=BLOODGROUP_CHOICES)

    def __str__(self):
        return f"{self.Name}, {self.City}"

RATING_CHOICES = [
    ('1 Star', '1'),
    ('2 Star', '2'),
    ('3 Star', '3'),
    ('4 Star', '4'),
    ('5 Star', '5'),
]

QUALITY_CHOICES = [
    ('Good','G'),
    ('Average','A'),
    ('Poor','P'),
]

STATUS_CHOICES = [
    ('Available','A'),
    ('Not Available','N'),
]

class Plasma(models.Model):
    PlasmaID = models.IntegerField
    Bloodbank = models.ForeignKey(Bloodbank,default=1, verbose_name="Bloodbank", on_delete=models.SET_DEFAULT)
    Bloodgroup = models.CharField(max_length=30,
    choices=BLOODGROUP_CHOICES)
    Donor = models.ForeignKey(Donor,default=1, verbose_name="Donor", on_delete=models.SET_DEFAULT,limit_choices_to=limit_donors_30days)
    DonationDate = models.DateField
    Status = models.CharField(max_length=20,
    choices = STATUS_CHOICES)
    Recipient = models.ForeignKey(Recipient,blank=True, default=1, verbose_name="Recipient", on_delete=models.SET_DEFAULT)
    AvailableQty = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name_plural = "Plasma List"
        

class Feedback(models.Model):
    FeedbackID = models.IntegerField
    Name = models.CharField(max_length=100)
    FeedbackDate = models.DateField
    Comments = models.CharField(max_length=250)
    Rating = models.CharField(max_length=10,choices = RATING_CHOICES)

    def __str__(self):
        return f"{self.Rating}, {self.Name}"