from django import forms

GENDER_CHOICES =[
    ('Male', 'M'),
    ('Female', 'F'),
]

BLOODGROUP_CHOICES = [
    ('A RhD positive', 'A+'),
    ('A RhD negative', 'A-'),
    ('B RhD positive', 'B+'),
    ('B RhD negative', 'B-'),
    ('O RhD positive', 'O+'),
    ('O RhD negative', 'O-'),
    ('AB RhD positive', 'AB+'),
    ('AB RhD negative', 'AB-'),
]
class RegisterForm(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    gender = forms.CharField(widget=forms.Select(choices=GENDER_CHOICES))
    aadhar = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    city = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    district = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    state = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    pincode = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    phone = forms.CharField(widget=forms.NumberInput(attrs={'class':'form-control'}))
    contact = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    bloodgroup = forms.CharField(widget=forms.Select(choices=BLOODGROUP_CHOICES))
    covidpositivedate = forms.DateField(widget = forms.SelectDateWidget)
    covidnegativedate = forms.DateField(widget = forms.SelectDateWidget)
